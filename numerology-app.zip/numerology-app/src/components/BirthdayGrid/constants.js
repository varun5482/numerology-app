export const BASE_GRID = [
  { value: 4, count: 0 },
  { value: 9, count: 0 },
  { value: 2, count: 0 },
  //Second Row
  { value: 3, count: 0 },
  { value: 5, count: 0 },
  { value: 7, count: 0 },
  //Third Row
  { value: 8, count: 0 },
  { value: 1, count: 0 },
  { value: 6, count: 0 },
];
