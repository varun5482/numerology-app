import "./App.css";
import BirthDateEvaluator from "./pages/BirthDateEvaluator";

function App() {
  return (
    <>
      <BirthDateEvaluator />
    </>
  );
}

export default App;
